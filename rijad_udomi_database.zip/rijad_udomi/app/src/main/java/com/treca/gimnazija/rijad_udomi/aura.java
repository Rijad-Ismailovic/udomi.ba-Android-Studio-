package com.treca.gimnazija.rijad_udomi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class aura extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aura);
    }
}